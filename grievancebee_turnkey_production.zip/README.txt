GrievanceBee Allegation Engine — Turnkey SPA + Netlify Functions Backend

Contents:
- index.html           : Single-file SPA with local allegation engine + SUPER-INQUIRY sender
- netlify/functions/grievancebee.js : Netlify Function that receives SUPER_INQUIRY and calls OpenAI
- netlify.toml         : Netlify configuration (publish + functions)

To use:
1. Set environment variable OPENAI_API_KEY in Netlify (or local).
2. Deploy this folder as a Netlify site.
3. Visit the site, describe an incident, analyze locally, and optionally send SUPER-INQUIRY to the AI backend.

Safety:
- Backend is instructed not to provide legal advice, only informational organization of potential issues.
