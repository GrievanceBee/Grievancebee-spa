// netlify/functions/grievancebee.js
// GrievanceBee Allegation Engine backend adapter
// Expects POST with { super_inquiry: { ... } }

export async function handler(event, context) {
  try {
    if (event.httpMethod !== "POST") {
      return {
        statusCode: 405,
        body: JSON.stringify({ error: "Method not allowed. Use POST." })
      };
    }

    if (!event.body) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: "Missing request body." })
      };
    }

    let parsed;
    try {
      parsed = JSON.parse(event.body);
    } catch (e) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: "Invalid JSON in request body." })
      };
    }

    const super_inquiry = parsed.super_inquiry;
    if (!super_inquiry || !super_inquiry.user_incident) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: "Missing super_inquiry or user_incident." })
      };
    }

    // API key selection: user-provided overrides server key
    const serverKey = process.env.OPENAI_API_KEY;
    const userKey = event.headers["x-user-openai-key"] || event.headers["X-User-OpenAI-Key".toLowerCase()];
    const apiKey = userKey || serverKey;

    if (!apiKey) {
      return {
        statusCode: 500,
        body: JSON.stringify({ error: "No OpenAI API key configured." })
      };
    }

    const systemPrompt = [
      "You are the GrievanceBee Allegation Engine.",
      "You receive a JSON 'super_inquiry' describing a user's incident, context, and pre-selected allegations.",
      "You operate under a governance regime that avoids giving jurisdiction-specific legal advice.",
      "You must NOT give definitive legal conclusions or guarantees.",
      "Instead, you flag potential or likely categories of issues, organize them, and help the user describe what happened.",
      "Output MUST be a single JSON object with the keys:",
      "core_allegations (array of strings),",
      "supplemental_allegations (array of strings),",
      "allegation_narrative (string),",
      "missing_fact_prompts (array of strings),",
      "recommended_next_steps (array of strings).",
      "All text must remain information-oriented and non-judgmental."
    ].join(" ");

    const userContent = JSON.stringify(super_inquiry);

    const body = {
      model: "gpt-4.1",
      temperature: 0.2,
      response_format: { type: "json_object" },
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userContent }
      ]
    };

    const openaiRes = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": "Bearer " + apiKey
      },
      body: JSON.stringify(body)
    });

    if (!openaiRes.ok) {
      const text = await openaiRes.text();
      console.error("OpenAI error:", openaiRes.status, text);
      return {
        statusCode: 502,
        body: JSON.stringify({ error: "OpenAI upstream error", detail: text })
      };
    }

    const openaiJson = await openaiRes.json();
    const content = openaiJson.choices?.[0]?.message?.content || "{}";

    let parsedContent;
    try {
      parsedContent = JSON.parse(content);
    } catch (e) {
      parsedContent = { raw: content };
    }

    const normalized = {
      core_allegations: parsedContent.core_allegations || [],
      supplemental_allegations: parsedContent.supplemental_allegations || [],
      allegation_narrative: parsedContent.allegation_narrative || "",
      missing_fact_prompts: parsedContent.missing_fact_prompts || [],
      recommended_next_steps: parsedContent.recommended_next_steps || [],
      raw_model_payload: parsedContent
    };

    return {
      statusCode: 200,
      body: JSON.stringify(normalized)
    };

  } catch (err) {
    console.error("Handler error:", err);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Internal server error" })
    };
  }
}
